package com.example.midnidemo

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private fun field(hint: String): EditText = EditText(this).apply {
        this.hint = hint
        textSize = 16f
        setSingleLine(true)
        setPadding(24, 12, 24, 12)
        background = getDrawable(android.R.drawable.edit_text)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        val title = TextView(this).apply {
            text = "Midni · DNI de demostración"
            textSize = 23f
            setTextColor(Color.rgb(25, 45, 70))
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        val warning = TextView(this).apply {
            text = "EJEMPLO FICTICIO — NO VÁLIDO"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(180, 30, 30))
            setPadding(8, 18, 8, 18)
        }
        root.addView(warning)
        val name = field("Nombre ficticio")
        val surnames = field("Apellidos ficticios")
        val number = field("Número de ejemplo (p. ej. 00000000T)")
        val birth = field("Fecha de nacimiento (DD/MM/AAAA)")
        listOf(name, surnames, number, birth).forEach {
            root.addView(it, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 10 })
        }
        val photoLabel = TextView(this).apply {
            text = "Foto: esta demo no almacena ni modifica documentos reales."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(4, 8, 4, 12)
        }
        root.addView(photoLabel)
        val preview = TextView(this).apply {
            text = "VISTA PREVIA\nEJEMPLO FICTICIO — NO VÁLIDO"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(120, 25, 25))
            setBackgroundColor(Color.WHITE)
            setPadding(16, 28, 16, 28)
        }
        root.addView(preview, LinearLayout.LayoutParams(-1, 170).apply { bottomMargin = 14 })
        val update = Button(this).apply {
            text = "Actualizar vista previa"
            setOnClickListener {
                preview.text = "EJEMPLO FICTICIO — NO VÁLIDO\n" +
                    "Nombre: ${name.text}\n" +
                    "Apellidos: ${surnames.text}\n" +
                    "Número: ${number.text}\n" +
                    "Nacimiento: ${birth.text}\n\nNO ES UN DOCUMENTO OFICIAL"
            }
        }
        root.addView(update, LinearLayout.LayoutParams(-1, 54))
        val note = TextView(this).apply {
            text = "La aplicación solo crea una ficha de prueba. No reproduce el diseño oficial del DNI ni genera documentos utilizables como identificación."
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(4, 16, 4, 0)
        }
        root.addView(note)
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }
}
