# Midni Demo (Android)

Aplicación Android de demostración para editar una ficha de identidad **completamente ficticia**.
La vista previa incluye de forma visible «EJEMPLO FICTICIO — NO VÁLIDO». No reproduce el diseño
oficial del DNI, no genera documentos de identidad y no debe utilizarse para alterar documentos reales.

## Compilar
1. Instala Android Studio (versión reciente) y abre esta carpeta como proyecto.
2. Espera a que Gradle sincronice.
3. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio generará el APK en `app/build/outputs/apk/debug/`.

Requisitos: Android SDK 35 y JDK compatible con Android Studio.
